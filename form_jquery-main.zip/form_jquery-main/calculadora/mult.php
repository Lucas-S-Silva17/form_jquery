<?php
$n1 = isset($_POST['num1']) ? floatval($_POST['num1']) : 0;
$n2 = isset($_POST['num2']) ? floatval($_POST['num2']) : 0;
$resultado = $n1 * $n2;
echo $resultado;
?>